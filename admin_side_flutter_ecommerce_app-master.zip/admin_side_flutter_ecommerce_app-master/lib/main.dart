import 'package:flutter/material.dart';
import 'package:shop_app_admin/screens/admin.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Admin(),
  ));
}